<?php
header("location: login.php");
include './views/meta.html';
?>