<?php
include './includes/handler.inc.php';
new Database();
new Confirm();
include './views/meta.html';
include './views/confirm.html';
?>

